<?php
  // een verbinding leggen met de databank
$servername = "127.0.0.1:51526";
$username = "azure";
$password = "6#vWHD_$";
$dbname = "project";// 
    
    // Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname) or die(mysqli_connect_error());

    
   
?>